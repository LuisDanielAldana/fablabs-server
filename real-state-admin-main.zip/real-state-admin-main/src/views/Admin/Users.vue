<template>
    <div>
        <h1>Users View</h1>
    </div>

</template>

<script>
export default {
  name: "UsersView"
}
</script>

<style scoped>

</style>